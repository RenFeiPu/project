//
//  AppDelegate.h
//  test
//
//  Created by 浅佳科技 on 2019/2/13.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

