//
//  CodeLabel.h
//  SegmentDemo
//
//  Created by 浅佳科技 on 2019/2/18.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CodeLabel : UILabel

@property (copy) NSString *plaintext;

@end

NS_ASSUME_NONNULL_END
