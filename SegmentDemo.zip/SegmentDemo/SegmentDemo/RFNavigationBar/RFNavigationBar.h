//
//  RFNavigationBar.h
//  NaviTest
//
//  Created by 浅佳科技 on 2019/3/13.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RFNavigationBar : UIView

@property (copy, nonatomic) NSString *title;
@property (strong, nonatomic) UIColor *titleColor;

- (void)setLeftTitle:(NSString *)title image:(NSString *)image leftClick:(void(^)(void))leftBlock;

- (void)setRightTitle:(NSString *)title image:(NSString *)image RightClick:(void(^)(void))RightBlock;

@end

NS_ASSUME_NONNULL_END
