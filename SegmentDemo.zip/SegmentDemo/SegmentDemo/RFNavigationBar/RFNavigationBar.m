//
//  RFNavigationBar.m
//  NaviTest
//
//  Created by 浅佳科技 on 2019/3/13.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import "RFNavigationBar.h"

@interface RFNavigationBar ()

@property (strong, nonatomic) UILabel *titleLabel;

@property (strong, nonatomic) UIButton *leftButton;
@property (strong, nonatomic) UIButton *rightButton;
@property (copy, nonatomic) void (^LeftBlock)(void);
@property (copy, nonatomic) void (^RightBlock)(void);

@end

@implementation RFNavigationBar

#define statusHeight [UIApplication sharedApplication].statusBarFrame.size.height

-(instancetype)init{
    
    self = [super init];
    if (self) {
        self.frame = CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), statusHeight+44);
        self.backgroundColor = [UIColor cyanColor];
        [self createSubViews];
    }
    return self;
}

-(void)createSubViews{
    
    self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(80, statusHeight, CGRectGetWidth(self.frame)-160, 44)];
    self.titleLabel.font = [UIFont boldSystemFontOfSize:19];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = [UIColor whiteColor];
    [self addSubview:self.titleLabel];
    
    self.leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.leftButton.frame = CGRectMake(0, statusHeight, 80, 44);
    [self.leftButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.leftButton.hidden = YES;
    [self addSubview:self.leftButton];
    
    self.rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.rightButton.frame = CGRectMake(CGRectGetWidth(self.frame)-80, statusHeight, 80, 44);
    [self.rightButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.rightButton.hidden = YES;
    [self addSubview:self.rightButton];
}

-(void)setTitle:(NSString *)title{
    
    _title = title;
    self.titleLabel.text = title;
}

-(void)setTitleColor:(UIColor *)titleColor{
    
    _titleColor = titleColor;
    self.titleLabel.textColor = titleColor;
    [self.leftButton setTitleColor:titleColor forState:UIControlStateNormal];
    [self.rightButton setTitleColor:titleColor forState:UIControlStateNormal];
}

-(void)setLeftTitle:(NSString *)title image:(NSString *)image leftClick:(void (^)(void))leftBlock{
    
    self.leftButton.hidden = NO;
    [self.leftButton setTitle:title forState:UIControlStateNormal];
    [self.leftButton setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [self.leftButton addTarget:self action:@selector(leftClick) forControlEvents:UIControlEventTouchUpInside];
    self.LeftBlock = leftBlock;;
}

-(void)setRightTitle:(NSString *)title image:(NSString *)image RightClick:(void (^)(void))RightBlock{
    
    self.rightButton.hidden = NO;
    [self.rightButton setTitle:title forState:UIControlStateNormal];
    [self.rightButton setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [self.rightButton addTarget:self action:@selector(rightClick) forControlEvents:UIControlEventTouchUpInside];
    self.RightBlock = RightBlock;
}

-(void)leftClick{
    
    self.LeftBlock();
}

-(void)rightClick{
    
    self.RightBlock();
}


@end
