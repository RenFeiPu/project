//
//  BaseTableView.h
//  test
//
//  Created by 浅佳科技 on 2019/2/14.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseTableView : UITableView<UIGestureRecognizerDelegate>

@end

NS_ASSUME_NONNULL_END
