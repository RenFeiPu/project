//
//  BaseTableView.m
//  test
//
//  Created by 浅佳科技 on 2019/2/14.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import "BaseTableView.h"

@implementation BaseTableView

-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    
    return YES;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
