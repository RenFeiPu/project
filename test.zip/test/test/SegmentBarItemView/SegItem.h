//
//  SegItem.h
//  InstrumentPro
//
//  Created by 浅佳科技 on 2018/12/28.
//  Copyright © 2018年 KuaiZhunCheFu. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SegItem : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UIView *bottomLine;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomLineWidth;


@end

NS_ASSUME_NONNULL_END
