//
//  SubViewController.h
//  test
//
//  Created by 浅佳科技 on 2019/2/13.
//  Copyright © 2019 浅佳科技. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubViewController : UIViewController

@property (strong) UITableView *tableView;
@property (assign) BOOL canScroll;
@property (copy) NSString *type;

@end

NS_ASSUME_NONNULL_END
